package com.restApiFileSystem.RestApiFileSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiFileSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
