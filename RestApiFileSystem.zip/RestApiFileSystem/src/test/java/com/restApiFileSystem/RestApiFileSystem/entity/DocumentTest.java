package com.restApiFileSystem.RestApiFileSystem.entity;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DocumentTest {
    private DocumentTest documentTest;
    @BeforeEach
    void setUp() {
        documentTest = new DocumentTest();
    }

    @AfterEach
    void tearDown() {
        documentTest = null;
    }

    @Test
    void getId() {

    }


    @Test
    void setId() {

    }

    @Test
    void getFileName() {
    }

    @Test
    void setFileName() {
    }

    @Test
    void getFileType() {
    }

    @Test
    void setFileType() {
    }

    @Test
    void getFileSize() {
    }

    @Test
    void setFileSize() {
    }

    @Test
    void getData() {
    }

    @Test
    void setData() {
    }

    @Test
    void getEmployee() {
    }

    @Test
    void setEmployee() {
    }

    @Test
    void getUploadedAt() {
    }

    @Test
    void setUploadedAt() {
    }
}