package com.restApiFileSystem.RestApiFileSystem.entity;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
class EmployeeTest {
    private Employee employee;

    @BeforeEach
    void setUp() {
        employee=new Employee();
    }

    @AfterEach
    void tearDown() {
        employee = null;
    }

    @Test
    void getId() {
        employee.setId(1L);
        assertEquals(1L,employee.getId(),"Get id fun is running");
    }

    @Test
    void setId() {
        employee.setId(1L);
        assertEquals(1L, employee.getId(), "Set id fun is running");
    }


    @Test
    void getName() {
        employee.setName("John Doe");
        assertEquals("John Doe", employee.getName(), "Get name fun is running");
    }

    @Test
    void setName() {
        employee.setName("John Doe");
        assertEquals("John Doe", employee.getName(), "Set name fun is running");
    }

    @Test
    void getPosition() {
        employee.setPosition("Manager");
        assertEquals("Manager", employee.getPosition(), "Get position fun is running");
    }

    @Test
    void setPosition() {
        employee.setPosition("Manager");
        assertEquals("Manager", employee.getPosition(), "Set position fun is running");
    }

    @Test
    void getDocuments() {
        Document document = new Document();
        employee.getDocuments().add(document);
        assertEquals(1, employee.getDocuments().size(), "Get documents fun is running");
    }

    @Test
    void setDocuments() {
        Document document = new Document();
        employee.getDocuments().add(document);
        assertEquals(1, employee.getDocuments().size(), "Set documents fun is running");
    }
}