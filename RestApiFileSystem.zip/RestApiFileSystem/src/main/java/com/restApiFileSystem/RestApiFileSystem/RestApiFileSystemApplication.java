package com.restApiFileSystem.RestApiFileSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestApiFileSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestApiFileSystemApplication.class, args);
	}

}
